﻿Public Class OpenFile
    Private Sub OpenFile_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim TempFileName As String = ""
        Dim FileStream As IO.FileStream
        Dim n As Integer
        Dim Mes As String = ""
        Dim i As Integer
        Dim SecLength As Long = 0
        Dim UnknowLength As Long = 0
        Dim EnzymeLength As Long = 0
        Dim PropertyLength As Long = 0
        Dim SecProperty As String = ""
        Dim VectorName As String = ""
        Dim FeatureLength As Long = 0
        Dim SecFeature As String = ""
        Dim PrimerLength As Long = 0
        Dim SecPrimer As String = ""
        Dim NoteLength As Long = 0
        Dim SecNote As String = ""
        Dim FileInfor As String = ""
        Dim VNTIFileName As String = ""
        Dim ValueArray() As String
        Dim ValueStart As Integer
        Dim ValueLen As Integer
        Dim ValueMid As Integer
        Dim CMDLine As String = ""
        Dim FileType As String = ""

        If Command() <> "" Then
            TempFileName = Replace(Command, Chr(34), "")
            OpenFileDialog1.FileName = TempFileName
            FileStream = OpenFileDialog1.OpenFile()

            Dim bytes(FileStream.Length + 20) As Byte
            Dim numBytesToRead As Integer = FileStream.Length
            Dim numBytesRead As Integer = 0
            'Change file extention to lower case


            If LCase(Strings.Right(TempFileName, 4)) = ".dna" Then
                FileType = ".dna"
                TempFileName = Replace(TempFileName, ".DNA", ".dna")
                VectorName = Replace(TempFileName, ".dna", "")
            End If

            If LCase(Strings.Right(TempFileName, 4)) = ".seq" Then
                FileType = ".seq"
                TempFileName = Replace(TempFileName, ".SEQ", ".seq")
                VectorName = Replace(TempFileName, ".seq", "")
            End If

            If LCase(Strings.Right(TempFileName, 6)) = ".fasta" Then
                FileType = ".fasta"
                TempFileName = Replace(TempFileName, ".FASTA", ".fasta")
                VectorName = Replace(TempFileName, ".fasta", "")
            End If

            VectorName = Strings.Right(VectorName, Strings.Len(VectorName) - InStrRev(VectorName, "\"))
            Dim MolType As String = ""
            Dim SecMol As String = ""
            Dim NoteText As String = ""

            'process SnapGene format
            If FileType = ".dna" Then
                ' Check for SnapGene format.
                Mes = ""
                n = FileStream.Read(bytes, 1, 13)
                For i = 6 To 13
                    Mes = Mes + Chr(bytes(i))
                Next
                If Mes = "SnapGene" Then
                    'Read file length and plasmid type
                    n = FileStream.Read(bytes, 14, 12)
                    SecLength = bytes(21) * 256 * 256 * 256 + bytes(22) * 256 * 256 + bytes(23) * 256 + bytes(24)
                    If bytes(25) = 2 Then MolType = "1" Else MolType = "0"
                    ' Read Secquence
                    n = FileStream.Read(bytes, 0, SecLength)
                    For i = 0 To SecLength - 2
                        SecMol = SecMol + Chr(bytes(i))
                    Next
                    'read unknown
                    n = FileStream.Read(bytes, 1, 4)
                    UnknowLength = bytes(1) * 256 * 256 * 256 + bytes(2) * 256 * 256 + bytes(3) * 256 + bytes(4)
                    n = FileStream.Read(bytes, 0, UnknowLength)
                    'read enzyme
                    n = FileStream.Read(bytes, 0, 5)
                    EnzymeLength = bytes(1) * 256 * 256 * 256 + bytes(2) * 256 * 256 + bytes(3) * 256 + bytes(4)
                    n = FileStream.Read(bytes, 0, EnzymeLength)
                    'read property
                    n = FileStream.Read(bytes, 0, 5)
                    PropertyLength = bytes(1) * 256 * 256 * 256 + bytes(2) * 256 * 256 + bytes(3) * 256 + bytes(4)
                    n = FileStream.Read(bytes, 0, PropertyLength)
                    For i = 0 To PropertyLength - 1
                        SecProperty = SecProperty + Chr(bytes(i))
                    Next
                    'read feature
                    n = FileStream.Read(bytes, 0, 5)
                    FeatureLength = bytes(1) * 256 * 256 * 256 + bytes(2) * 256 * 256 + bytes(3) * 256 + bytes(4)
                    n = FileStream.Read(bytes, 0, FeatureLength)
                    For i = 0 To FeatureLength - 1
                        SecFeature = SecFeature + Chr(bytes(i))
                    Next
                    'read primer
                    n = FileStream.Read(bytes, 0, 5)
                    PrimerLength = bytes(1) * 256 * 256 * 256 + bytes(2) * 256 * 256 + bytes(3) * 256 + bytes(4)
                    n = FileStream.Read(bytes, 0, PrimerLength)
                    For i = 0 To PrimerLength - 1
                        SecPrimer = SecPrimer + Chr(bytes(i))
                    Next
                    'read Notes
                    n = FileStream.Read(bytes, 0, 5)
                    NoteLength = bytes(1) * 256 * 256 * 256 + bytes(2) * 256 * 256 + bytes(3) * 256 + bytes(4)
                    n = FileStream.Read(bytes, 0, NoteLength)
                    For i = 0 To NoteLength - 1
                        SecNote = SecNote + Chr(bytes(i))
                    Next
                    SecLength = SecLength - 1
                Else
                    MsgBox("File format is incorrect! Please double check the file is valid SnapGene viewer file.")
                End If
                ' Create archive files .ma4
                FileInfor = "@551656AS34@" + vbCrLf + "SnapGene File" + vbCrLf + "267|SnapGene" + vbCrLf + "212" + vbCrLf + "25|" + VectorName + vbCrLf + "27|0" + vbCrLf + "222|1" + vbCrLf + "33|" + CStr(SecLength) + vbCrLf + "236|525886601" + vbCrLf + "237|525893303" + vbCrLf + "26|1209" + vbCrLf + "28|0" + vbCrLf + "219|0" + vbCrLf + "220|1" + vbCrLf + "221|1" + vbCrLf + "29|0" + vbCrLf + "30|0" + vbCrLf + "217|0" + vbCrLf + "31|0" + vbCrLf + "32|1" + vbCrLf + "255" + vbCrLf + "224|SnapVector" + vbCrLf + "50" + vbCrLf + "256" + vbCrLf + "224|SnapVector" + vbCrLf + "50" + vbCrLf + "1001|0" + vbCrLf
            End If

            'process EtenBio sequencing format
            If FileType = ".seq" Then
                SecMol = My.Computer.FileSystem.ReadAllText(TempFileName)
                SecMol = Strings.Replace(SecMol, Chr(10), "")
                SecMol = Strings.Replace(SecMol, Chr(13), "")
                SecLength = Strings.Len(SecMol)
                SecFeature = ""
                SecNote = "248|Sequencing result of " + VectorName + vbCrLf

                ' Create archive files .ma4
                FileInfor = "@551656AS34@" + vbCrLf + "Sequencing File" + vbCrLf + "267|SnapGene" + vbCrLf + "212" + vbCrLf + "25|" + VectorName + vbCrLf + "27|0" + vbCrLf + "222|1" + vbCrLf + "33|" + CStr(SecLength) + vbCrLf + "236|525886601" + vbCrLf + "237|525893303" + vbCrLf + "26|1209" + vbCrLf + "28|0" + vbCrLf + "219|0" + vbCrLf + "220|1" + vbCrLf + "221|1" + vbCrLf + "29|0" + vbCrLf + "30|0" + vbCrLf + "217|0" + vbCrLf + "31|0" + vbCrLf + "32|1" + vbCrLf + "255" + vbCrLf + "224|SnapVector" + vbCrLf + "50" + vbCrLf + "256" + vbCrLf + "224|SnapVector" + vbCrLf + "50" + vbCrLf + "1001|0" + vbCrLf
            End If

            If FileType = ".fasta" Then
                SecMol = My.Computer.FileSystem.ReadAllText(TempFileName)
                SecMol = Strings.Replace(SecMol, Chr(13), "")
                ValueArray = Split(SecMol, Chr(10))
                SecNote = ValueArray(0)
                If Strings.Left(SecNote, 1) = ">" Then
                    SecNote = Strings.Right(SecNote, Len(SecNote) - 1) + vbCrLf
                    i = 0
                    SecMol = ""
                    For Each item In ValueArray
                        i = i + 1
                        If i > 1 Then SecMol = SecMol + item
                    Next
                    SecMol = Strings.Replace(SecMol, " ", "")
                    SecLength = Strings.Len(SecMol)
                    SecFeature = ""
                    ' Create archive files .ma4
                    FileInfor = "@551656AS34@" + vbCrLf + "Fasta File" + vbCrLf + "267|Fasta" + vbCrLf + "212" + vbCrLf + "25|" + Replace(SecNote, "|", " ") + vbCrLf + "27|0" + vbCrLf + "222|1" + vbCrLf + "33|" + CStr(SecLength) + vbCrLf + "236|525886601" + vbCrLf + "237|525893303" + vbCrLf + "26|1209" + vbCrLf + "28|0" + vbCrLf + "219|0" + vbCrLf + "220|1" + vbCrLf + "221|1" + vbCrLf + "29|0" + vbCrLf + "30|0" + vbCrLf + "217|0" + vbCrLf + "31|0" + vbCrLf + "32|1" + vbCrLf + "255" + vbCrLf + "224|SnapVector" + vbCrLf + "50" + vbCrLf + "256" + vbCrLf + "224|SnapVector" + vbCrLf + "50" + vbCrLf + "1001|0" + vbCrLf
                    SecNote = "248|" + SecNote + vbCrLf
                    SecNote = Strings.Replace(SecNote, "|", vbCrLf + "248|")
                Else
                    MsgBox("File format is incorrect! Please double check the file is valid SnapGene viewer file.")
                End If
            End If
            FileStream.Close()

            'Writing Features
            If Strings.Len(SecFeature) > 0 And InStr(SecFeature, "</Feature>") > 0 Then
                'MsgBox(SecFeature)
                SecFeature = Replace(SecFeature, "&lt;i&gt;", "")
                SecFeature = Replace(SecFeature, "&lt;/i&gt;", "")
                SecFeature = Replace(SecFeature, "&amp;", "&")
                SecFeature = Replace(SecFeature, "nbsp;", " ")

                ValueArray = Split(SecFeature, "</Feature>")
                For Each item In ValueArray
                    If InStr(item, "</Features>") <= 0 Then
                        ValueStart = InStr(item, " name=")
                        ValueLen = InStr(Strings.Right(item, item.Length - ValueStart - 6), Chr(34))
                        FileInfor = FileInfor + "45" + vbCrLf + "51|4" + vbCrLf + "52|" + Strings.Mid(item, ValueStart + 7, ValueLen - 1) + vbCrLf
                        If InStr(item, "<Q name=""note""><V text=""&lt;html&gt;&lt;body&gt;") > 0 Then
                            ValueStart = InStr(item, "<Q name=""note""><V text=""&lt;html&gt;&lt;body&gt;")
                            ValueLen = InStr(Strings.Right(item, item.Length - ValueStart - 48), "&lt;/body&gt;&lt;/html&gt;""/></Q>")
                            NoteText = "54|" + Strings.Mid(item, ValueStart + 48, ValueLen) + vbCrLf
                        Else
                            NoteText = ""
                        End If
                        ValueStart = InStr(item, "<Segment range=")
                        ValueMid = InStr(Strings.Right(item, item.Length - ValueStart - 16), "-")
                        ValueLen = InStr(Strings.Right(item, item.Length - ValueStart - 16 - ValueMid), Chr(34))
                        If Strings.Mid(item, ValueStart + 16, ValueMid) > Strings.Mid(item, ValueStart + ValueMid + 16 + 1, ValueMid) Then
                            FileInfor = FileInfor + "53|1" + vbCrLf + NoteText + "55|" + Strings.Mid(item, ValueStart + ValueMid + 16 + 1, ValueMid) + vbCrLf + "56|" + Strings.Mid(item, ValueStart + 16, ValueMid) + vbCrLf
                        Else
                            FileInfor = FileInfor + "53|0" + vbCrLf + NoteText + "55|" + Strings.Mid(item, ValueStart + 16, ValueMid) + vbCrLf + "56|" + Strings.Mid(item, ValueStart + ValueMid + 16 + 1, ValueMid) + vbCrLf
                        End If
                        FileInfor = FileInfor + "57|0" + vbCrLf + "281|1" + vbCrLf + "282|1" + vbCrLf + "283|1" + vbCrLf + "284|1" + vbCrLf + "50" + vbCrLf
                    End If
                Next
            End If

            FileInfor = FileInfor + "205" + vbCrLf + "37|0" + vbCrLf + "38|0" + vbCrLf + "39|0" + vbCrLf + "40|0" + vbCrLf

            'write note information
            If SecNote <> "" Then
                If Strings.Len(SecNote) > 0 And InStr(SecNote, "</Notes>") > 0 Then
                    SecNote = Replace(SecNote, "Notes>", "")
                    ValueArray = Split(SecNote, "</")
                    SecNote = ""
                    For Each item In ValueArray
                        item = Strings.Mid(item, InStr(item, ">") + 1, Strings.Len(item) - InStr(item, ">"))
                        item = Replace(item, "&lt;body>", "")
                        item = Replace(item, "&lt;/body>", "")
                        item = Replace(item, "&lt;html>", "")
                        item = Replace(item, "&lt;/html>", "")
                        item = Replace(item, "<", "")
                        item = Replace(item, "&lt;", "<")
                        item = Strings.Replace(item, Chr(13), "")
                        item = Strings.Replace(item, Chr(10), "")
                        item = Replace(item, "<div>", vbCrLf + "248|")
                        item = Replace(item, "</div>", "")
                        item = Replace(item, "<br>", vbCrLf + "248|")
                        item = Replace(item, ">", ": ")
                        SecNote = SecNote + "248|" + item + vbCrLf
                    Next
                End If
                FileInfor = FileInfor + "250" + vbCrLf + SecNote
                FileInfor = FileInfor + "50" + vbCrLf
            End If
            FileInfor = FileInfor + "1024|-1" + vbCrLf + "24" + vbCrLf

            'Add sequence
            For i = 1 To Len(SecMol) Step 1000
                FileInfor = FileInfor + "209|" + Mid(SecMol, i, 1000) + vbCrLf
            Next
            FileInfor = FileInfor + "210" + vbCrLf + "207"

            'Write archive file and open in VectorNTI
            If FileType = ".dna" Then
                My.Computer.FileSystem.WriteAllText(Replace(TempFileName, ".dna", ".ma4"), FileInfor, False, System.Text.Encoding.ASCII)

                CMDLine = "Explorer " + Replace(TempFileName, ".dna", ".ma4")
            End If
            If FileType = ".seq" Then
                My.Computer.FileSystem.WriteAllText(Replace(TempFileName, ".seq", ".ma4"), FileInfor, False, System.Text.Encoding.ASCII)
                CMDLine = "Explorer " + Replace(TempFileName, ".seq", ".ma4")
            End If
            If FileType = ".fasta" Then
                My.Computer.FileSystem.WriteAllText(Replace(TempFileName, ".fasta", ".ma4"), FileInfor, False, System.Text.Encoding.ASCII)
                CMDLine = "Explorer " + Replace(TempFileName, ".fasta", ".ma4")
            End If

            Shell(CMDLine)
            Application.Exit()
        Else
            MsgBox("Open SnapGene File Or DNA sequencing file With SnapVector " + System.Windows.Forms.Application.ProductVersion)
            Application.Exit()
        End If
    End Sub
End Class
